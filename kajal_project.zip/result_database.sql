-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 07, 2016 at 10:39 AM
-- Server version: 5.7.12-0ubuntu1.1
-- PHP Version: 7.0.4-7ubuntu2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `result_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_name` varchar(100) DEFAULT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_name`, `branch_id`) VALUES
('Computer Science and Engineering', 1),
('Electronics and Communication Engineering', 2),
('Electrical and Electronics Engineering', 3),
('Civil Engineering', 4),
('Mechanical Engineering', 5),
('Chemical Engineering', 6);

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `semester` int(11) NOT NULL,
  `sem_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`semester`, `sem_name`) VALUES
(1, 'first'),
(2, 'second'),
(3, 'third'),
(4, 'fourth'),
(5, 'fifth'),
(6, 'sixth'),
(7, 'seventh'),
(8, 'eighth');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `branch` varchar(60) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `rollno` bigint(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `branch`, `semester`, `rollno`, `subject_name`, `marks`) VALUES
(2, 'KAJAL', 'COMPUTER SCIENCE AND ENGINEERING', 'FIFTH', 13518, 'THEORY OF COMPUTATION', 86),
(3, 'KAJAL', 'COMPUTER SCIENCE AND ENGINEERING', 'FIFTH', 13518, 'COMPUTER NETWORKS', 98),
(6, 'TESTUSER', 'COMPUTER SCIENCE AND ENGINEERING', 'FIRST', 12211, 'THERY OF COMPUTATION', 87),
(7, 'MUNI', 'ELECTRONICS AND COMMUNICATION ENGINEERING', 'FIFTH', 13519, 'COMPUTER NETWORKS', 85),
(8, 'KAJAL', 'COMPUTER SCIENCE AND ENGINEERING', 'FIFTH', 13518, 'COMPILER DESIGN', 95),
(9, 'KAJAL', 'COMPUTER SCIENCE AND ENGINEERING', 'FIFTH', 13518, 'DATA STRUCTURE', 87),
(10, 'KAJAL', 'COMPUTER SCIENCE AND ENGINEERING', 'FIFTH', 13518, 'DISCRETE STRUCTURE', 79);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`semester`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `semester` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
