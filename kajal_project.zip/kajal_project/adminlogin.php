<?php 
  include_once 'connection.php';
  session_start();
  if (isset($_SESSION['id'])) {
    header("Location:admin.php");
  }
  $msg="";
  if (isset($_POST['submit'])) {
	  	$username = $_POST['username'];
      $password = $_POST['password'];
      if ($username=="kajal" && $password=="admin123") {
        $_SESSION['id']=1;
        $_SESSION['msg']="Successfully Logged In";
        header("Location:admin.php");
      }
      else{
        $msg="Invalid details entered";
      }
  }

 ?>
<!DOCTYPE html>
<html>
<head>
<title>Admin-Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>

<?php include_once 'navbar.php'; ?>
<div class="container">

	
  <div class="well col-md-8 col-md-offset-2">
      <h2 align="center">Admin Login</h2>
        <?php if ($msg!=""): ?>
            <div class="alert alert-danger">
              <?php echo $msg; ?>
            </div>
        <?php endif ?>
      <br>
  <form class="form-horizontal" method="post" action="">

        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Username</label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="inputEmail3" placeholder="Username" name="username">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Password</label>
            <div class="col-sm-6">
              <input type="password" class="form-control" id="inputEmail3" placeholder="Password" name="password">
            </div>
        </div>
		<div class="form-group">
          <div class="col-sm-offset-3 col-sm-10">
            <button type="submit" class="btn btn-info" name="submit">Log In</button>
          </div>
        </div>

    <br>
     
</form>
    
  </div>
</div>

</body>
</html>

