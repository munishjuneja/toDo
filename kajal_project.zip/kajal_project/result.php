<?php 
	include_once 'connection.php';

	
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>
 		RESULT
 	</title>
 	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
 	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
 	<link rel="stylesheet" type="text/css" href="css/custom.css">
 </head>
 <body>
 	<?php include_once 'navbar.php'; ?>

 	<div class="col-sm-6 col-sm-offset-3">
 	<table class = "table table-bordered table-striped" >
 		<h1 align="center">Result details</h1>
      <thead style="background:#456; opacity:0.7; color:white;">
      <?php 
         		$rollno=$_GET['roll'];
         		$query=mysqli_query($con,"SELECT * from students where rollno='$rollno'");
         		$nameresult = mysqli_fetch_array($query);
          ?>

         <tr>
            <th>Name</th>
            <td><?php echo $nameresult['name']; ?></td>
         </tr>
         <tr>
            <th>Semester</th>
            <td><?php echo $nameresult['semester']; ?></td>
         </tr>
         <tr>
            <th>Branch</th>
            <td><?php echo $nameresult['branch']; ?></td>
         </tr>
         </thead>
        
     
      
      <tbody style="background:white;">
      		 <?php 
         		$roll=$_GET['roll'];
         		$query2=mysqli_query($con,"SELECT * from students where rollno='$rollno'");
         		$sum=0;
         		$i=0;
         		while ($result = mysqli_fetch_array($query2)) {
         			
         		
          ?>
          <tr>
          	<th><?php echo $result['subject_name']; ?></th>
          	<td><?php echo $result['marks'];
          			$sum+=$result['marks'];
          			$i++;
          	 ?></td>
          </tr>
          <?php
          	}
          ?>
          <tr>
          	<th>Total marks</th>
          	<td><?php echo $sum; ?></td>
          </tr>
          <tr>
         	<th>Percentage</th>
         	<td><?php echo ($sum/$i)." %"; ?></td>
          </tr>
       
      </tbody>    
   </table>
 	</div>
 
 </body>
 </html>