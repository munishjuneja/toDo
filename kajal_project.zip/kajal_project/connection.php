<?php 
	$con = mysqli_connect('localhost','root','strongpassword','result_database');
	
 ?>