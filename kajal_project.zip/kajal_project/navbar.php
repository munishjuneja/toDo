<nav class="navbar navbar-default" style="background:#222; border:none;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">BIS RESULT PORTAL</a>
    </div>
    <div style="float:right; margin:20px;">
      <?php if (isset($_SESSION['id'])): ?>
          <a href="logout.php" style="color:white;">Logout</a>
      <?php endif ?>
  </div>
  </div>
  
</nav>