<?php 
  include_once 'connection.php';
  session_start();
  if (isset($_POST['byname'])) {
     $semester=strtoupper($_POST['sem_name']);
      $name= strtoupper($_POST['name']);
      echo $semester;
      echo $name;
      $arr = array();
      $i=0;
      $query = mysqli_query($con, "SELECT * from students where `semester`='$semester' and `name` like '%$name%'");
      while($result = mysqli_fetch_array($query)){
          $arr[$i]=$result['rollno'];
          $i++;
      }
      $_SESSION['unique']=array_unique($arr);
      header("Location:search_result.php");        

  }
  if (isset($_POST['byroll'])) {
    $roll=strtoupper($_POST['roll']);
    header("Location:result.php?roll=$roll");
  }
 ?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<?php include_once 'navbar.php'; ?>
  <form class="form-horizontal" method="post" action="select_semester.php">
<div class="container">
  <div class="well col-md-8 col-md-offset-2">
      <h3 align="center">SELECT YOUR SEMESTER</h3>
      <br>

      <div class="form-group">
          <div class="dropdown" style="margin-left:120px; margin-right:30px;" >
            <label style="margin-right:30px;">Semester</label>
            <button id="hash" class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">---Select Your semester----
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
              <?php 
                  $query = mysqli_query($con,"SELECT * from semester");
                  while ($out = mysqli_fetch_array($query)) {
                      
                  
               ?>
               <li align="center" class="idLink"><?php echo $out['sem_name']; ?></li>
               <?php
                }
               ?>
            </ul> 
          </div>
        </div>    
    <br>
    <input type="hidden" id="sem_input" name="sem_name">
      <div class="well">
            <h1 class="col-sm-8 col-sm-offset-4">Search by Name</h1>
          <div class="form-group">
              <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Name</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" id="inputEmail3" placeholder="Enter name here" name="name">
              </div>
          </div>
        
        <div class="form-group">
          <div class="col-sm-offset-3 col-sm-10">
            <button type="submit" class="btn btn-default" name="byname">Check result</button>
          </div>
        </div>
      </div>
      <div class="well">
            <h1 class="col-sm-8 col-sm-offset-4">Search by Roll No. <noframes></noframes></h1>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Roll no</label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="inputEmail3" placeholder="Enter roll no here" name="roll">
            </div>
        </div>
        
        <div class="form-group">
          <div class="col-sm-offset-3 col-sm-10">
            <button type="submit" class="btn btn-default" name="byroll">Check result</button>
          </div>
        </div>
      </div>

       
</form>
    
  </div>
</div>
<script type="text/javascript">
  
   jQuery(document).ready(function(){
           jQuery('.idLink').click(function(){
              var x=$(this).html();

                $("#hash").html($(this).html()+"&nbsp;&nbsp<span class=\"caret\"></span>");
                $("#sem_input").val(x);
                $("sem_input").attr("value",x);


           });


      });
</script>

</body>
</html>

