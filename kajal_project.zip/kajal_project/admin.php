<?php 
  include_once 'connection.php';
  session_start();
  if (!isset($_SESSION['id'])) {
  		header("Location:adminlogin.php");
  }
  if (isset($_POST['submit'])) {
	  	$sem = strtoupper($_POST['sem_name']);
	  	$branch = strtoupper($_POST['branch_name']);
	  	$name = strtoupper($_POST['name']);
	  	$rollno = strtoupper($_POST['rollno']);
	  	$marks = strtoupper($_POST['marks']);
	  	$subject= strtoupper($_POST['subject_name']);
	  	mysqli_query($con,"INSERT INTO students(`name`,`branch`,`semester`,`rollno`,`subject_name`,`marks`) values('$name','$branch','$sem','$rollno','$subject','$marks')");
	  	$_SESSION['message']="Student details successfully added";
  }

 ?>
<!DOCTYPE html>
<html>
<head>
<title>Admin-Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>

<?php include_once 'navbar.php'; ?>
<div class="container">

	
  <div class="well col-md-8 col-md-offset-2">
 	 
      <h3 align="center">SELECT YOUR SEMESTER</h3>
      <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success">
              <?php echo $_SESSION['message']; ?>
            </div>
        <?php endif ?>
        <?php if (isset($_SESSION['msg'])): ?>
		<div class="alert alert-info"><?php echo $_SESSION['msg']; ?></div>
			<?php unset($_SESSION['msg']); ?>
		<?php endif ?>
      <br>
  <form class="form-horizontal" method="post" action="">
      <div class="form-group">
          <div class="dropdown" style="margin-left:120px; margin-right:30px;" >
            <label style="margin-right:30px;">Semester</label>
            <button id="hash" class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">---select semester----
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
              <?php 
                  $query = mysqli_query($con,"SELECT * from semester");
                  while ($out = mysqli_fetch_array($query)) {
                      
                  
               ?>
               <li align="center" class="idLink"><?php echo $out['sem_name']; ?></li>
               <?php
                }
               ?>
            </ul> 
          </div>
        </div> 
        <input type="hidden" id="sem_input" name="sem_name">

        <div class="form-group">
          <div class="dropdown" style="margin-left:136px; margin-right:30px;" >
            <label style="margin-right:30px;">Branch</label>
            <button id="hash2" class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">---select branch----
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
              <?php 
                  $query = mysqli_query($con,"SELECT * from branches");
                  while ($out = mysqli_fetch_array($query)) {
                      
                  
               ?>
               <li align="center" class="idLink2"><?php echo $out['branch_name']; ?></li>
               <?php
                }
               ?>
            </ul> 
          </div>
        </div>  
        <input type="hidden" name="branch_name" id="branch_input">

        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Name</label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="inputEmail3" placeholder="Enter student name here" name="name">
            </div>
        </div>
         <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Roll no</label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="inputEmail3" placeholder="Enter roll no here" name="rollno">
            </div>
        </div> 
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Subject name</label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="inputEmail3" placeholder="Enter subject name here" name="subject_name">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 col-sm-offset-1 control-label">Marks Obtained</label>
            <div class="col-sm-6">
              <input type="text" class="form-control" id="inputEmail3" placeholder="Enter marks obtained here" name="marks">
            </div>
        </div>
		<div class="form-group">
          <div class="col-sm-offset-3 col-sm-10">
            <button type="submit" class="btn btn-info" name="submit">Enter details</button>
          </div>
        </div>

    <br>
     
</form>
    
  </div>
</div>
<script type="text/javascript">
  
	  jQuery(document).ready(function(){
	           jQuery('.idLink').click(function(){
	           		var x=$(this).html();

	                $("#hash").html($(this).html()+"&nbsp;&nbsp<span class=\"caret\"></span>");
	                $("#sem_input").val(x);
	                $("sem_input").attr("value",x);


	           });


	      });

  jQuery(document).ready(function(){
           jQuery('.idLink2').click(function(){
           		var x=$(this).html();
                  $("#hash2").html($(this).html()+"&nbsp;&nbsp<span class=\"caret\"></span>");
                $("#branch_input").attr("value",x);

           });

      });
</script>

</body>
</html>

