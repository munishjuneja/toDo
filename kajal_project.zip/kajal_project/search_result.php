<?php 
	include_once 'connection.php';
	session_start();
 	
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>RESULT PORTAL</title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    
</head>

<body ><!-- nav bar for intermediate pages -->

<?php include_once 'navbar.php'; ?>
		<div class = "containerfluid" style="margin-top:40px;">
				<div class="container">
						<div class = "row">
								<div class = "col-lg-12" >
									
									<div class = "col-lg-8 col-lg-offset-2" >
										
										<div id="list4">
										   	<ul class="list-group">
										   


										     <li  class="list-group-item" style="font-size:20px;"><span><span style="margin-left:30px;">Search Results</span></span></li>
										     	<?php $arr = $_SESSION['unique']; ?>
										     	
										     	<?php if (count($arr)==0){?>
										     			<li class="list-group-item"><a class="list-group-item"><span ></span>
										    	 				No Results found
													    	 </a>

													    	 		
													      	</li>

										     		
										     	<?php }else
										     	 { ?>
										      		<?php foreach ($arr as $value){ ?>
										      			<?php 
										      				$query = mysqli_query($con,"SELECT * from students where rollno='$value'");
										      					$result = mysqli_fetch_array($query);
										      		 	?>
										      				<li class="list-group-item"><a href="result.php?roll=<?php echo $result['rollno']; ?>" class="list-group-item"><span ></span>
										    	 				<?php echo $result['rollno']."&nbsp; - &nbsp;"; ?>
										    	 				<?php echo $result['name']."&nbsp; - &nbsp;"; ?>
										    	 				<?php echo $result['branch']; ?>
													    	 	</a>

													    	 		
													      	</li>
										      		
										      		<?php } ?>


										      	<?php
										      		}
										      	?>
										    	 
										      
										      
										   	</ul>
										</div>
										
									</div>	
										
								</div>
						</div>				
				</div>
		</div>
</body>
</html>	