<?php 
	include_once 'connection.php';
 	



 ?>


<!DOCTYPE html>
<html>
<head>
	<title>RESULT PORTAL</title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    
</head>

<body ><!-- nav bar for intermediate pages -->

<?php include_once 'navbar.php'; ?>
		<div class = "containerfluid" style="margin-top:40px;">
				<div class="container">
						<div class = "row">
								<div class = "col-lg-12" >
									
									<div class = "col-lg-8 col-lg-offset-2" >
										
										<div id="list4">
										   	<ul class="list-group">
										   


										     <li  class="list-group-item" style="font-size:20px;"><span><span style="margin-left:30px;">Select your Branch</span></span></li>
										    		<?php 

															$query = mysqli_query($con, "SELECT * from branches");
															
															while($out=mysqli_fetch_array($query)){
															
												   	 ?>
										    	 <li class="list-group-item"><a href="select_semester.php?id=<?php echo $out['branch_id'];?>"class="list-group-item"><span ></span>
										    	 		<?php echo $out['branch_name']; ?>
										    	 </a>

										    	 		
										      	</li>
										      		<?php
										      		}
										      	?>
										      
										   	</ul>
										</div>
										
									</div>	
										
								</div>
						</div>				
				</div>
		</div>
</body>
</html>